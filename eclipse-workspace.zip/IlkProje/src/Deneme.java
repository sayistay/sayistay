
public class Deneme {
	public static void main(String[] args) {
		System.out.println("Merhaba");
	}
}
