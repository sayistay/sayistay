public class Ornekler {

	public static void main(String[] args) {
		byte a = 3, b = 4;
		long l = 100_000_000_000L;
		float f = 2.5f;
		double d = 3.0;
		System.out.println(d);

		d = 012;
		System.out.println(d);
		d = 0xFF;
		System.out.println(d);

		d = 0b00100101;
		System.out.println(d);

		char c = 'a';
		System.out.println(c);
		c = '\b';
		c = '\t';
		c = '\r';
		c = '\u011e';
		System.out.println(c);

		boolean acik = false;
		System.out.println(acik);
	}
}
