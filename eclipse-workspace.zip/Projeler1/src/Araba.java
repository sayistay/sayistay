
public class Araba {
	int hiz;
}
