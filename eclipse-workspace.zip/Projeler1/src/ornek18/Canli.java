package ornek18;

class Canli {
	int yas;

	int getYas() {
		return yas;
	}

}
