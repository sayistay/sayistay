package ornek19;

class Hayvan extends Canli {
	int yas = 2;

	int getYas() {
		return yas;
	}

}
