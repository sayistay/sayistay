package ornek19;

class Canli {
	int yas = 1;

	int getYas() {
		return yas;
	}

}
