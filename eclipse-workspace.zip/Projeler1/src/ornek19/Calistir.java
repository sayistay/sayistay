package ornek19;

public class Calistir {
	public static void main(String[] args) {
		Canli canli = new Hayvan();
		canli.yas = 3;
		System.out.println(canli.getYas());
	}
}
