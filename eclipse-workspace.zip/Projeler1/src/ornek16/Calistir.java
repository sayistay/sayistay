package ornek16;

import static ornek16.Hesap.topla;

public class Calistir {
	public static void main(String[] args) {
		// System.out.println(Hesap.topla(2, 3));
		System.out.println(topla(2, 3));
	}
}
