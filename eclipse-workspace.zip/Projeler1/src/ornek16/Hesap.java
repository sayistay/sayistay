package ornek16;

public class Hesap {
	static int topla(int sayi1, int sayi2) {
		return sayi1 + sayi2;
	}
}
