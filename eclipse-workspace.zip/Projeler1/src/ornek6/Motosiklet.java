package ornek6;

public class Motosiklet {
	int fiyat;

	Motosiklet(int yeniFiyat) {
		fiyat = yeniFiyat;
	}

	Motosiklet() {
	}
}
