package ornek17;

public class Hayvan extends Canli {
	String renk;

	public String getRenk() {
		return renk;
	}

}
