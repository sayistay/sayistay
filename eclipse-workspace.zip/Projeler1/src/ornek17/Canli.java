package ornek17;

public class Canli {
	protected int yas;

	public int getYas() {
		return yas;
	}

}
