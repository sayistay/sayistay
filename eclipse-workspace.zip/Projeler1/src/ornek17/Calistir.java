package ornek17;

public class Calistir {
	public static void main(String[] args) {
		Hayvan hayvan = new Hayvan();
		hayvan.yas = 3;
		System.out.println(hayvan.getYas());
	}
}
