package ornek8;

public class Calistir {
	public static void main(String[] args) {
		Motosiklet motosiklet = new Motosiklet();
		System.out.println(motosiklet.fiyat);
		System.out.println(motosiklet.renk);
	}
}
