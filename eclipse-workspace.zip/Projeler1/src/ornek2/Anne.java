package ornek2;

public class Anne {
	String adi;
	Anne anne;
}
