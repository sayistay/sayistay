package ornek;

public class Anne {
	int yas;
	String adi;
}
