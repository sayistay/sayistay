package ornek4;

public class Bilgisayar {
	String model = "101";
	static String marka = "HP";

	String getModel() {
		return model;
	}

	static String getMarka() {
		return marka;
	}
}
