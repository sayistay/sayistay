package ornek20;

class Canli {
	private int yas = 1;

	int getYas() {
		return yas;
	}

	void setYas(int yas) {
		this.yas = yas;
	}

}
