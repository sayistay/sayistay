package ornek20;

public class Calistir {
	public static void main(String[] args) {
		Canli canli = new Hayvan();
		canli.setYas(3);
		System.out.println(canli.getYas());
	}
}
