package ornek20;

class Hayvan extends Canli {
	private int yas = 2;

	int getYas() {
		return yas;
	}

	void setYas(int yas) {
		this.yas = yas;
	}
}
