
public class Ornek1 {

	public static void main(String[] args) {
		Araba araba1 = new Araba();
		Araba araba2 = new Araba();
		araba1.hiz = 30;
		araba2.hiz = 50;
		System.out.println(araba1.hiz);
		System.out.println(araba2.hiz);

	}
}
