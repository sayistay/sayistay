package ornek5;

public class Calistir {

	public static void main(String[] args) {
		System.out.println("Program basladi.");
		System.out.println(Masa.model());
		System.out.println(Masa.model());
	}

}
