package ornek7;

public class Motosiklet {
	int fiyat;

	public Motosiklet(int fiyat) {
		this.fiyat = fiyat;
	}

	Motosiklet() {
	}
}
